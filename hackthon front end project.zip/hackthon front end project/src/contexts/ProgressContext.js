// src/contexts/ProgressContext.js
import { createContext } from 'react'

export const ProgressContext = createContext()